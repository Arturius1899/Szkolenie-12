package pl.sda.training.java;

public class Buldog extends Pies {

    public Buldog() {
        super("Buldog");
    }

    @Override
    public String szczekaj() {
        return "hauhau2";
    }

}
