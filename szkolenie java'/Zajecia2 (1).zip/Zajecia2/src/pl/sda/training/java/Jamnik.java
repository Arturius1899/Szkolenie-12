package pl.sda.training.java;

public class Jamnik extends Pies {

    public Jamnik() {
        super("Jamnik");
    }

    @Override
    public String szczekaj() {
        return "hauhau hau";
    }

}
