package pl.sda.training.java;

public class Sznaucer extends Pies {

    public Sznaucer() {
        super("Sznaucer");
    }

    @Override
    public String szczekaj() {
        return "hauhau";
    }

//    public String szczekajJakZwyklyPies() {
//        return super.szczekaj();
//    }
}
