package pl.sda.training.java;

public class Husky extends Pies {

    public Husky() {
        super("Husky");
    }

    @Override
    public String szczekaj() {
        return "hauhau hau hau hau";
    }

}
