package pl.sda.java.basic.solution.homework3.printer;

/**
 * @author Michal Jaszczyk
 **/
public class Main {
    public static void main(String[] args) {
        Drukarka.piatka();
        Drukarka.kot();
        Drukarka.choinka(10);
    }
}
