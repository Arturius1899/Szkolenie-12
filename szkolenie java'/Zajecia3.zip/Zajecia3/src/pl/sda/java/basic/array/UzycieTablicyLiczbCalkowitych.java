package pl.sda.java.basic;

public class UzycieTablicyLiczbCalkowitych {
    private TablicaLiczbCalkowitych tablica =
            new TablicaLiczbCalkowitych(new int[]{1,2,3,5});
}
