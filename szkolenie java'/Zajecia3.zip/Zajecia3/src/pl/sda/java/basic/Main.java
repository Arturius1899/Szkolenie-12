package pl.sda.java.basic;

public class Main {
    public static void main(String[] args) {
        PrzykladKlasy naszaPierwszaPrzykladowaKlasa = new PrzykladKlasy();
        naszaPierwszaPrzykladowaKlasa.przykladowaMetoda();
        naszaPierwszaPrzykladowaKlasa.dajJesc(0);
    }
}
