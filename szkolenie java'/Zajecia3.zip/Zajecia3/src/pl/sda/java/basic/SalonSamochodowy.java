package pl.sda.java.basic;

import java.util.ArrayList;
import java.util.List;

public class SalonSamochodowy {
    private List<Samochod> samochodyDoSprzedazy = new ArrayList<>();
}
