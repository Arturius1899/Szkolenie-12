package pl.sda.java.basic.interfacing;

public class Muchomor extends Grzyb {
}
