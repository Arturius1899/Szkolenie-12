package pl.sda.java.basic.inheritance;

/**
 * @author Michal Jaszczyk
 **/
public class Skoda extends Samochod {

    public Skoda() {
        // Niejawnie wywoływany jest bezparametrowy konstruktor z klasy Samochod
        System.out.println("Tworzę obiekt typu Skoda");
    }
}
