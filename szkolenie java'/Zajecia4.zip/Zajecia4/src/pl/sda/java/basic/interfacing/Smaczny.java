package pl.sda.java.basic.interfacing;

public interface Smaczny {

    void mniam();
}
