package pl.sda.java.basic.interfacing;

public interface Blaszkowe {
}
