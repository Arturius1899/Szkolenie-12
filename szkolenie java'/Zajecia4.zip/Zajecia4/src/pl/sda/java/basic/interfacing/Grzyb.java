package pl.sda.java.basic.interfacing;

public abstract class Grzyb {

    public void zbierz() {
        System.out.println("zbieram grzyba");
    }
}
